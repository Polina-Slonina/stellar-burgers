export { ProtectedRoute } from './protectedRoute';
