import {
  createSelector,
  createSlice,
  nanoid,
  PayloadAction
} from '@reduxjs/toolkit';
import { TConstructorIngredient, TIngredient } from '@utils-types';
import { useMemo } from 'react';

// Типы состояния
interface BurgerConstructorState {
  bun: TIngredient | null; // Добавьть нужный тип
  ingredients: TConstructorIngredient[];
}

const initialState: BurgerConstructorState = {
  bun: null,
  ingredients: []
};

// Слайс
export const burgerconstructorSlice = createSlice({
  name: 'burgerconstructor',
  initialState,
  reducers: {
    setBun(state, action: PayloadAction<TIngredient>) {
      state.bun = action.payload;
    },
    addIngredient(state, action: PayloadAction<TIngredient>) {
      // Преобразование ингредиента в TConstructorIngredient с добавлением id
      const newIngredient: TConstructorIngredient = {
        ...action.payload,
        id: nanoid() // Здесь генерируется уникальный id
      };
      if (action.payload.type === 'bun') {
        state.bun = action.payload;
      } else {
        state.ingredients.push(newIngredient);
      }
    },
    moveIngredientUp(state, action: PayloadAction<number>) {
      const { payload: oldIndex } = action;
      const newIndex = oldIndex - 1;

      // Копируем массив ингредиентов
      const ingredients = [...state.ingredients];

      // Меняем местами элементы
      [ingredients[newIndex], ingredients[oldIndex]] = [
        ingredients[oldIndex],
        ingredients[newIndex]
      ];

      // Обновляем состояние
      state.ingredients = ingredients;
    },
    moveIngredientDown(state, action: PayloadAction<number>) {
      const { payload: oldIndex } = action;
      const newIndex = oldIndex + 1;

      // Копируем массив ингредиентов
      const ingredients = [...state.ingredients];

      // Меняем местами элементы
      [ingredients[newIndex], ingredients[oldIndex]] = [
        ingredients[oldIndex],
        ingredients[newIndex]
      ];

      // Обновляем состояние
      state.ingredients = ingredients;
    },
    // removeIngredient(state, action: PayloadAction<number>) {
    //   const { payload: indexToRemove } = action;

    //   // Фильтруем массив ингредиентов, исключая элемент с указанным индексом
    //   state.ingredients = state.ingredients.filter(
    //     (_, index) => index !== indexToRemove
    //   );
    // },
    removeIngredient(state, action: PayloadAction<number>) {
      state.ingredients.splice(action.payload, 1);
    },
    clearIngredients(state) {
      state.ingredients = [];
      state.bun = null;
    }
    // setOrderRequest(state, action: PayloadAction<boolean>) {
    //   state.orderRequest = action.payload;
    // },
    // setOrderModalData(state, action: PayloadAction<any>) {
    //   state.orderModalData = action.payload;
    // }
  },
  selectors: {
    getIngredients: (state) => state.ingredients,
    // Селектор для получения всех элементов конструктора
    getConstructorItems: (state) => state
    // getConstructorItems: createSelector(
    //   [(state) => state.bun, (state) => state.ingredients],
    //   (bun, ingredients) => ({
    //     bun,
    //     ingredients
    //   })
    // )
  }
});

export const { getIngredients, getConstructorItems } =
  burgerconstructorSlice.selectors;

// Экспорт действий
export const {
  setBun,
  addIngredient,
  removeIngredient,
  clearIngredients,
  moveIngredientUp,
  moveIngredientDown
} = burgerconstructorSlice.actions;

// Экспорт редьюсера
export default burgerconstructorSlice.reducer;
