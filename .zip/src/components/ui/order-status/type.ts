export type OrderStatusUIProps = {
  textStyle: string;
  text: string;
};
