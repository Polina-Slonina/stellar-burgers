import {
  Action,
  createAsyncThunk,
  createSlice,
  PayloadAction
} from '@reduxjs/toolkit';
import { TUser } from '@utils-types';
import {
  fetchLogout,
  fetchRegisterUser,
  fetchUpdateUser,
  fetchUser,
  setUser
} from './actionsUser';

interface UserState {
  isAuthChecked: boolean;
  success: boolean;
  user: TUser | null;
  loading: boolean;
  errorUser: string | null;
  errorRegister: string | null;
}

const initialState: UserState = {
  isAuthChecked: false,
  success: false,
  user: null,
  loading: false,
  errorUser: null,
  errorRegister: null
};

interface RejectedAction extends Action {
  loading: boolean;
  error: Error;
}

// Функция предикат для проверки совпадений с запросами к API
const isPendingAction = (action: Action): action is RejectedAction =>
  action.type.endsWith('/pending');

const isRejectedAction = (action: Action): action is RejectedAction =>
  action.type.endsWith('/rejected');

export const userSlice = createSlice({
  name: 'user',
  initialState,
  reducers: {
    authCheck: (state, action: PayloadAction<boolean>) => {
      state.isAuthChecked = action.payload;
      console.log('проверяем что значение обновилось:', state.isAuthChecked);
    }
    // clearUserErrors: (state) => {
    //   state.error = null; // Очистка ошибки
    // }
  },
  selectors: {
    getUser: (state) => state.user,
    getIsAuthChecked: (state) => state.isAuthChecked,
    getSuccess: (state) => state.success,
    getUserLoading: (state) => state.loading,
    registerUserError: (state) => state.errorRegister,
    loginUserError: (state) => state.errorUser
  },
  extraReducers: (builder) => {
    builder
      .addCase(fetchUser.pending, (state) => {
        state.loading = true;
        state.errorUser = null;
      })
      .addCase(fetchUser.rejected, (state, action) => {
        state.loading = false;
        state.errorUser = action.error?.message ?? 'Unknown error';
      })
      .addCase(fetchUser.fulfilled, (state, action) => {
        console.log('Данные с сервера user:', action.payload); // Логирование данных
        console.log('булево значение :', state.loading);
        state.loading = false;
        state.user = action.payload.user;
        state.success = action.payload.success;
        state.isAuthChecked = true;
      })
      .addCase(fetchRegisterUser.pending, (state) => {
        state.loading = true;
        state.errorRegister = null;
      })
      .addCase(fetchRegisterUser.rejected, (state, action) => {
        state.loading = false;
        state.errorRegister = action.error?.message ?? 'Unknown error';
        console.log(state.errorRegister);
      })
      .addCase(fetchRegisterUser.fulfilled, (state, action) => {
        console.log('Данные с сервера userregister:', action.payload); // Логирование данных
        console.log('булево значение :', state.loading);
        state.loading = false;
        state.user = action.payload.user;
      })
      .addCase(fetchUpdateUser.fulfilled, (state, action) => {
        console.log('Данные с сервера userUpdate:', action.payload); // Логирование данных
        console.log('булево значение :', state.loading);
        state.loading = false;
        state.user = action.payload.user;
      })
      .addCase(fetchLogout.fulfilled, (state) => {
        state.user = null;
        console.log('Данные с сервера userLogout:', state.user); // Логирование данных
      })
      .addCase(setUser, (state, action) => {
        state.user = action.payload;
      });
    // .addMatcher(isPendingAction, (state) => {
    //   state.loading = true;
    //   state.error = null;
    // })
    // .addMatcher(isRejectedAction, (state, action) => {
    //   state.loading = false;
    //   state.error = action.error?.message ?? 'Unknown error';
    // });
    // .addCase(fetchGetUser.fulfilled, (state, action) => {
    //   state.user = action.payload.user;
    // });
  }
});

export const {
  getUser,
  getSuccess,
  getUserLoading,
  registerUserError,
  loginUserError,
  getIsAuthChecked
} = userSlice.selectors;

export const { authCheck } = userSlice.actions;
export default userSlice.reducer;

type ActionCreators = typeof userSlice.actions;

export type TInternalActions = ReturnType<ActionCreators[keyof ActionCreators]>;
